from user import User

bean = User("Nina", "Bean", "isacat", "nina@msudenver.edu", "860meowmeowmeow")

bean.DescribeUser()