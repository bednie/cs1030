from user import User

sutton = User("Ray", "Sutton", "900876123", "ray.sutton25252@msudenver.edu", "+8604097387")

sutton.DescribeUser()