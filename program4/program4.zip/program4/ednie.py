from user import User

ednie = User("Blair", "Ednie", "900456123", "blair@aol.com", "17204561234")

ednie.DescribeUser()